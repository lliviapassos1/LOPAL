# 11.CONTADOR REGRESSIVO

contador = 10
while contador >= 1:
    print(contador)
    contador -= 1
print("Serviço reiniciado!")
